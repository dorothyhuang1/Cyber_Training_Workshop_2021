f = open("ceo_gauss.out", "r")
g = open("ceo_gaussContracted.dat", "a+")
i = 0 
for line in f:
     if ( i%100 == 0 ):
          g.write(line)
     i = i + 1
