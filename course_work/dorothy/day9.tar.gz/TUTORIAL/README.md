1. Perform MCSCF Single point calculation for methanininium cation.
2. Perform MCRI Single point calculation for methanininium cation.

