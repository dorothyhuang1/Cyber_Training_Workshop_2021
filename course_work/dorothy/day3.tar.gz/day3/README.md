Did exercises in the matrix elements tutorial.
