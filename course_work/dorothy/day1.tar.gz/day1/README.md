Simpson's integration, euler and verlet algorithms
